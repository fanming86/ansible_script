---
- name: Install Python packages
  hosts: all
  gather_facts: no
  tasks:
  - name: 添加 Anaconda 路径到 /etc/profile
    lineinfile:
      path: /etc/profile
      line: 'export PATH="/usr/local/anaconda/bin:$PATH"'
      state: present
      create: false        # 不创建文件（确保文件已存在）
      insertafter: EOF     # 添加到文件末尾
      backup: true         # 修改前备份原文件
